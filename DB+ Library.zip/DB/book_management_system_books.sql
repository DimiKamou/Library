-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: book_management_system
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `books` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `isbn` varchar(13) DEFAULT NULL,
  `publication_date` date DEFAULT NULL,
  `genre` varchar(50) DEFAULT NULL,
  `summary` text,
  `cover_image_url` varchar(255) DEFAULT NULL,
  `author_id` int NOT NULL,
  `stock` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `isbn` (`isbn`),
  KEY `author_id` (`author_id`),
  CONSTRAINT `books_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `authors` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES (41,'1984','1234567890123','1949-06-08','Dystopian','A novel about a totalitarian regime and surveillance.',NULL,1,10,'2024-12-29 14:04:39','2024-12-29 14:04:39'),(42,'Animal Farm','2345678901234','1945-08-17','Political Satire','A satirical allegory about power and corruption.',NULL,1,12,'2024-12-29 14:04:39','2024-12-29 14:04:39'),(43,'To Kill a Mockingbird','3456789012345','1960-07-11','Fiction','A story of racial injustice in the Deep South.',NULL,2,8,'2024-12-29 14:04:39','2024-12-29 14:04:39'),(44,'The Great Gatsby','4567890123456','1925-04-10','Fiction','The tragic story of Jay Gatsby and his obsession with Daisy Buchanan.',NULL,3,5,'2024-12-29 14:04:39','2024-12-29 14:04:39'),(45,'Harry Potter and the Philosopher\'s Stone','5678901234567','1997-06-26','Fantasy','A young wizard’s first year at Hogwarts.',NULL,4,15,'2024-12-29 14:04:39','2024-12-29 14:04:39'),(46,'Harry Potter and the Chamber of Secrets','6789012345678','1998-07-02','Fantasy','Harry Potter uncovers a dark secret hidden within Hogwarts.',NULL,4,10,'2024-12-29 14:04:39','2024-12-29 14:04:39'),(47,'The Catcher in the Rye','7890123456789','1951-07-16','Fiction','A teenager’s critique of the adult world.',NULL,5,6,'2024-12-29 14:04:39','2024-12-29 14:04:39'),(48,'Pride and Prejudice','8901234567890','1813-01-28','Romance','A classic novel of manners and love.',NULL,6,10,'2024-12-29 14:04:39','2024-12-29 14:04:39'),(49,'The Hobbit','9012345678901','1937-09-21','Fantasy','Bilbo Baggins’ adventure to reclaim a treasure guarded by a dragon.',NULL,7,8,'2024-12-29 14:04:39','2024-12-29 14:04:39'),(50,'The Fellowship of the Ring','0123456789012','1954-07-29','Fantasy','The first volume of the epic Lord of the Rings trilogy.',NULL,7,7,'2024-12-29 14:04:39','2024-12-29 14:04:39'),(51,'The Shining','1234509876543','1977-01-28','Horror','A family in a haunted hotel faces supernatural forces.',NULL,8,9,'2024-12-29 14:04:39','2024-12-29 14:04:39'),(52,'It','2345609876543','1986-09-15','Horror','A group of children battles a shape-shifting entity in their hometown.',NULL,8,4,'2024-12-29 14:04:39','2024-12-29 14:04:39'),(53,'The Road','3456709876543','2006-09-26','Post-Apocalyptic','A father and son journey through a desolate, post-apocalyptic world.',NULL,9,3,'2024-12-29 14:04:39','2024-12-29 14:04:39'),(54,'The Alchemist','4567809876543','1988-05-01','Philosophy','A shepherd’s journey to discover his personal legend.',NULL,10,8,'2024-12-29 14:04:39','2024-12-29 14:04:39'),(55,'Fahrenheit 451','5678909876543','1953-10-19','Dystopian','A dystopian future where books are banned and burned.',NULL,11,12,'2024-12-29 14:04:39','2024-12-29 14:04:39'),(56,'Moby-Dick','6789009876543','1851-11-14','Adventure','The quest of Captain Ahab for revenge against the white whale Moby-Dick.',NULL,12,6,'2024-12-29 14:04:39','2024-12-29 14:04:39'),(57,'War and Peace','7890109876543','1869-01-01','Historical Fiction','A novel chronicling the lives of aristocrats during the Napoleonic Wars.',NULL,13,5,'2024-12-29 14:04:39','2024-12-29 14:04:39'),(58,'The Picture of Dorian Gray','8901209876543','1890-07-01','Philosophy','A young man’s portrait ages instead of him, reflecting his moral corruption.',NULL,14,7,'2024-12-29 14:04:39','2024-12-29 14:04:39'),(59,'Dracula','9012309876543','1897-05-26','Horror','The story of Count Dracula’s attempt to move from Transylvania to England.',NULL,15,8,'2024-12-29 14:04:39','2024-12-29 14:04:39'),(60,'The Odyssey','0123409876543','0800-01-01','Epic Poetry','Homer’s epic poem about the journey of Odysseus returning home.',NULL,16,10,'2024-12-29 14:04:39','2024-12-29 14:04:39');
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-30  9:58:04
