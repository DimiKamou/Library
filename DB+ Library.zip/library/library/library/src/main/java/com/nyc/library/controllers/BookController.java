package com.nyc.library.controllers;

import com.nyc.library.entities.Book;
import com.nyc.library.services.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/books")
public class BookController {

    private final BookService bookService;

    @Autowired
    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    // Fetch all books
    @GetMapping
    public String getAllBooks(Model model) {
        List<Book> allBooks = bookService.getAllBooks();
        model.addAttribute("books", allBooks);
        return "list-books"; // Ensure "list-books.html" exists
    }

    // Redirect the "Edit Book" sidebar to All Books
    @GetMapping("/edit")
    public String redirectToBooks() {
        return "redirect:/books";
    }

    // Fetch a specific book by ID
    @GetMapping("/{id}")
    public String getBookById(@PathVariable Integer id, Model model) {
        Optional<Book> book = bookService.getBookById(id);
        if (book.isPresent()) {
            model.addAttribute("book", book.get());
            return "view-book"; // Ensure "view-book.html" exists
        }
        model.addAttribute("errorMessage", "Book not found.");
        return "error/404"; // Custom error page
    }

    // Show the form for adding a new book
    @GetMapping("/add")
    public String showAddBookForm(Model model) {
        model.addAttribute("book", new Book());
        return "add-book"; // Ensure "add-book.html" exists
    }

    // Save a new book
    @PostMapping
    public String createBook(@ModelAttribute Book book) {
        bookService.saveBook(book);
        return "redirect:/books"; // Redirects to the list of books
    }

    // Show the form for editing a book
    // Example from your BookController
    @GetMapping("/edit/{id}")
    public String showEditBookForm(@PathVariable Integer id, Model model) {
        Optional<Book> book = bookService.getBookById(id);
        if (book.isPresent()) {
            model.addAttribute("book", book.get());
            return "edit-book"; // Ensure "edit-book.html" exists
        }
        model.addAttribute("errorMessage", "Book not found.");
        return "error/404"; // Ensure "error/404.html" exists
    }


    // Update an existing book
    @PostMapping("/update/{id}")
    public String updateBook(@PathVariable Integer id, @ModelAttribute Book updatedBook) {
        Optional<Book> existingBook = bookService.getBookById(id);
        if (existingBook.isPresent()) {
            updatedBook.setId(existingBook.get().getId());
            bookService.saveBook(updatedBook);
            return "redirect:/books"; // Redirects to the list of books
        }
        return "error/404"; // Custom error page
    }

    // Delete an existing book
    @PostMapping("/delete/{id}")
    public String deleteBook(@PathVariable Integer id) {
        if (bookService.getBookById(id).isPresent()) {
            bookService.deleteBook(id);
        }
        return "redirect:/books"; // Redirects to the list of books
    }
}
