package com.nyc.library.controllers;

import com.nyc.library.entities.Role;
import com.nyc.library.entities.User;
import com.nyc.library.services.RoleService;
import com.nyc.library.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/users")
public class UserController {

    private final UserService userService;
    private final RoleService roleService;

    @Autowired
    public UserController(UserService userService, RoleService roleService) {
        this.userService = userService;
        this.roleService = roleService;
    }

    // Fetch all users
    @GetMapping
    public String getAllUsers(Model model) {
        List<User> allUsers = userService.getAllLibraryUsers();
        model.addAttribute("users", allUsers);
        return "list-users";
    }

    // Redirect the "Edit User" sidebar to All Users
    @GetMapping("/edit")
    public String redirectToUsers() {
        return "redirect:/users";
    }

    // Fetch a specific user by ID
    @GetMapping("/{id}")
    public String getUserById(@PathVariable Integer id, Model model) {
        Optional<User> user = userService.getLibraryUserById(id);
        if (user.isPresent()) {
            model.addAttribute("user", user.get());
            return "view-user"; // Ensure "view-user.html" exists
        }
        model.addAttribute("errorMessage", "User not found.");
        return "error/404";
    }

    // Show the form for adding a new user
    @GetMapping("/add")
    public String showAddUserForm(Model model) {
        model.addAttribute("user", new User());
        model.addAttribute("roles", roleService.getAllRoles());
        return "add-user"; // Ensure "add-user.html" exists
    }

    // Save a new user
    @PostMapping("/add")
    public String createUser(@ModelAttribute User user) {
        userService.saveLibraryUser(user);
        return "redirect:/users";
    }

    // Show the form for editing a user
    @GetMapping("/edit/{id}")
    public String showEditUserForm(@PathVariable Integer id, Model model) {
        Optional<User> user = userService.getLibraryUserById(id);
        if (user.isPresent()) {
            model.addAttribute("user", user.get());
            model.addAttribute("roles", roleService.getAllRoles());
            return "edit-user";
        }
        model.addAttribute("errorMessage", "User not found.");
        return "error/404";
    }

    // Update an existing user
    @PostMapping("/update/{id}")
    public String updateUser(@PathVariable Integer id, @ModelAttribute User updatedUser) {
        Optional<User> existingUser = userService.getLibraryUserById(id);
        if (existingUser.isPresent()) {
            updatedUser.setId(existingUser.get().getId());
            userService.saveLibraryUser(updatedUser);
            return "redirect:/users";
        }
        return "error/404";
    }

    // Delete an existing user
    @PostMapping("/delete/{id}")
    public String deleteUser(@PathVariable Integer id) {
        if (userService.getLibraryUserById(id).isPresent()) {
            userService.deleteLibraryUser(id);
        }
        return "redirect:/users";
    }
}
