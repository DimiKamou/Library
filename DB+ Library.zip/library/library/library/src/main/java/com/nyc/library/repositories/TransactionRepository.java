package com.nyc.library.repositories;

import com.nyc.library.entities.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Integer> {

    // Fetch transactions by user ID
    List<Transaction> findByUserId(Integer userId);

    // Fetch transactions by book ID
    List<Transaction> findByBookId(Integer bookId);

    // Fetch transactions by type (e.g., "borrow" or "return")
    List<Transaction> findByTransactionType(String transactionType);

    // Count active loans (books not yet returned)
    long countByReturnedDateIsNull();

    // Find delayed loans (due date passed, book not returned)
    List<Transaction> findByDueDateBeforeAndReturnedDateIsNull(LocalDate today);
}
