package com.nyc.library.repositories;

import com.nyc.library.entities.Author;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuthorRepository extends JpaRepository<Author, Integer> {
    // The `findById` method is inherited from JpaRepository
}
