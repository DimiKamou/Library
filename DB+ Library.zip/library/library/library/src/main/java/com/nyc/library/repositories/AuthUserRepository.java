package com.nyc.library.repositories;

import com.nyc.library.entities.Myuser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuthUserRepository extends JpaRepository<Myuser, Integer> {
    Myuser findByUsernameAndUserpassword(String username, String password);
}
