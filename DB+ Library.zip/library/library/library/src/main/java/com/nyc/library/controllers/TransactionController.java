package com.nyc.library.controllers;

import com.nyc.library.entities.Transaction;
import com.nyc.library.services.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/transactions")
public class TransactionController {

    private final TransactionService transactionService;

    @Autowired
    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    // Redirect from /loans/check to /transactions/check
    @GetMapping("/loans/check")
    public String handleLoansCheck() {
        return "redirect:/transactions/check";
    }

    // Handle requests for /transactions/check
    @GetMapping("/check")
    public String checkLoans(Model model) {
        long loanCount = transactionService.countRentedBooks();
        List<Transaction> delayedLoans = transactionService.findDelayedTransactions();

        model.addAttribute("loanCount", loanCount);
        model.addAttribute("delayedLoans", delayedLoans);

        return "check-loans"; // Ensure this template exists
    }

    // Fetch all transactions
    @GetMapping
    public String getAllTransactions(Model model) {
        List<Transaction> allTransactions = transactionService.getAllTransactions();
        model.addAttribute("transactions", allTransactions);
        return "list-transactions";
    }

    // Fetch a transaction by ID
    @GetMapping("/{id}")
    public String getTransactionById(@PathVariable Integer id, Model model) {
        return transactionService.getTransactionById(id)
                .map(transaction -> {
                    model.addAttribute("transaction", transaction);
                    return "view-transaction";
                })
                .orElse("error/404");
    }

    // Form to create a transaction
    @GetMapping("/new")
    public String showCreateTransactionForm(Model model) {
        model.addAttribute("transaction", new Transaction());
        return "create-transaction";
    }

    @PostMapping
    public String createTransaction(@ModelAttribute Transaction transaction) {
        transactionService.saveTransaction(transaction);
        return "redirect:/transactions";
    }

    // Form to edit a transaction
    @GetMapping("/edit/{id}")
    public String showEditTransactionForm(@PathVariable Integer id, Model model) {
        return transactionService.getTransactionById(id)
                .map(transaction -> {
                    model.addAttribute("transaction", transaction);
                    return "edit-transaction";
                })
                .orElse("error/404");
    }

    @PostMapping("/update/{id}")
    public String updateTransaction(@PathVariable Integer id, @ModelAttribute Transaction updatedTransaction) {
        return transactionService.getTransactionById(id)
                .map(existingTransaction -> {
                    updatedTransaction.setId(existingTransaction.getId());
                    transactionService.saveTransaction(updatedTransaction);
                    return "redirect:/transactions";
                })
                .orElse("error/404");
    }

    // Delete a transaction
    @PostMapping("/delete/{id}")
    public String deleteTransaction(@PathVariable Integer id) {
        if (transactionService.getTransactionById(id).isPresent()) {
            transactionService.deleteTransaction(id);
            return "redirect:/transactions";
        }
        return "error/404";
    }
}
