package com.nyc.library.services;

import com.nyc.library.entities.Transaction;
import com.nyc.library.repositories.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class TransactionService {

    private final TransactionRepository transactionRepository;

    @Autowired
    public TransactionService(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    // Fetch all transactions
    public List<Transaction> getAllTransactions() {
        return transactionRepository.findAll();
    }

    // Fetch a transaction by ID
    public Optional<Transaction> getTransactionById(Integer id) {
        return transactionRepository.findById(id);
    }

    // Fetch transactions for a specific user
    public List<Transaction> getTransactionsByUserId(Integer userId) {
        return transactionRepository.findByUserId(userId);
    }

    // Fetch transactions for a specific book
    public List<Transaction> getTransactionsByBookId(Integer bookId) {
        return transactionRepository.findByBookId(bookId);
    }

    // Fetch transactions by type (e.g., "borrow", "return")
    public List<Transaction> getTransactionsByType(String transactionType) {
        return transactionRepository.findByTransactionType(transactionType);
    }

    // Save or update a transaction
    public Transaction saveTransaction(Transaction transaction) {
        return transactionRepository.save(transaction);
    }

    // Delete a transaction by ID
    public void deleteTransaction(Integer id) {
        transactionRepository.deleteById(id);
    }

    // Count the total number of active loans (books not yet returned)
    public long countRentedBooks() {
        return transactionRepository.countByReturnedDateIsNull();
    }

    // Find transactions with overdue loans (due date passed, book not returned)
    public List<Transaction> findDelayedTransactions() {
        LocalDate today = LocalDate.now();
        return transactionRepository.findByDueDateBeforeAndReturnedDateIsNull(today);
    }
}
