package com.nyc.library.services;

import com.nyc.library.entities.Role;
import com.nyc.library.repositories.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RoleService {

    private final RoleRepository roleRepository;

    @Autowired
    public RoleService(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    public List<Role> getAllRoles() {
        return roleRepository.findAll();
    }

    public Optional<Role> getRoleById(Integer id) {
        return roleRepository.findById(id);
    }



    public Role saveRole(Role role) {
        role.setRoleName(role.getRoleName().toUpperCase().trim()); // Normalize role name
        return roleRepository.save(role);
    }

    public void deleteRole(Integer id) {
        if (!canDeleteRole(id)) {
            throw new IllegalArgumentException("Cannot delete role with ID: " + id + ". It is linked to existing users.");
        }
        roleRepository.deleteById(id);
    }

    private boolean canDeleteRole(Integer id) {
        // Example logic: Check if the role is linked to any users
        // Replace with the actual method if implemented in the user repository
        return true; // Update with validation logic if required
    }
}
