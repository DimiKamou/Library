package com.nyc.library.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "myuser", schema = "mydb")
public class Myuser {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "userid", nullable = false)
    private Integer id;

    @Column(name = "username", length = 20)
    private String username;

    @Column(name = "userpassword", length = 50)
    private String userpassword;

    @Column(name = "role", length = 20)
    private String role; // Role field added to define user roles (e.g., ADMIN, LIBRARIAN, MEMBER)

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserpassword() {
        return userpassword;
    }

    public void setUserpassword(String userpassword) {
        this.userpassword = userpassword;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
