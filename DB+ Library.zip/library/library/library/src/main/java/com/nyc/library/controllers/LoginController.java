package com.nyc.library.controllers;

import com.nyc.library.entities.Myuser;
import com.nyc.library.repositories.AuthUserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class LoginController {

    private final AuthUserRepository authUserRepository;

    @Autowired
    public LoginController(AuthUserRepository authUserRepository) {
        this.authUserRepository = authUserRepository;
    }

    @GetMapping("/")
    public String showLoginPage() {
        return "login"; // Render login.html
    }

    @PostMapping("/login")
    public String handleLogin(@RequestParam String username,
                              @RequestParam String password,
                              HttpSession session,
                              Model model) {
        Myuser user = authUserRepository.findByUsernameAndUserpassword(username, password);
        if (user != null) {
            session.setAttribute("loggedinuser", user);
            return "redirect:/index"; // Redirect to the index page
        } else {
            model.addAttribute("error", "Invalid username or password!");
            return "login";
        }
    }

    @GetMapping("/index")
    public String showIndexPage(HttpSession session, Model model) {
        Myuser user = (Myuser) session.getAttribute("loggedinuser");
        if (user == null) {
            return "redirect:/"; // Redirect to login if no user is logged in
        }
        model.addAttribute("loggedinuser", user);
        return "index"; // Render index.html
    }

    @GetMapping("/logout")
    public String handleLogout(HttpSession session) {
        // Invalidate the session to log the user out
        session.invalidate();

        // Redirect to the login page
        return "redirect:/";
    }
}
