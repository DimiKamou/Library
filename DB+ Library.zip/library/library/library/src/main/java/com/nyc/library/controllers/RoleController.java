package com.nyc.library.controllers;

import com.nyc.library.entities.Role;
import com.nyc.library.services.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/roles")
public class RoleController {

    private final RoleService roleService;

    @Autowired
    public RoleController(RoleService roleService) {
        this.roleService = roleService;
    }

    // Fetch and display all roles
    @GetMapping
    public String getAllRoles(Model model) {
        List<Role> allRoles = roleService.getAllRoles();
        model.addAttribute("roles", allRoles);
        return "list-roles"; // Ensure "list-roles.html" exists in the templates folder
    }

    // Fetch and display a single role by ID
    @GetMapping("/{id}")
    public String getRoleById(@PathVariable Integer id, Model model) {
        Optional<Role> role = roleService.getRoleById(id);
        if (role.isPresent()) {
            model.addAttribute("role", role.get());
            return "view-role"; // Ensure "view-role.html" exists in the templates folder
        } else {
            return "error/404"; // Ensure "error/404.html" exists
        }
    }

    // Show form to create a new role
    @GetMapping("/new")
    public String showCreateRoleForm(Model model) {
        model.addAttribute("role", new Role());
        return "create-role"; // Ensure "create-role.html" exists
    }

    // Handle creation of a new role
    @PostMapping
    public String createRole(@ModelAttribute Role role) {
        roleService.saveRole(role);
        return "redirect:/roles";
    }

    // Show form to edit an existing role
    @GetMapping("/edit/{id}")
    public String showEditRoleForm(@PathVariable Integer id, Model model) {
        Optional<Role> role = roleService.getRoleById(id);
        if (role.isPresent()) {
            model.addAttribute("role", role.get());
            return "edit-role"; // Ensure "edit-role.html" exists
        } else {
            return "error/404"; // Ensure "error/404.html" exists
        }
    }

    // Handle updating an existing role
    @PostMapping("/update/{id}")
    public String updateRole(@PathVariable Integer id, @ModelAttribute Role updatedRole) {
        Optional<Role> existingRole = roleService.getRoleById(id);
        if (existingRole.isPresent()) {
            // Retain the ID of the existing role
            updatedRole.setId(existingRole.get().getId());
            roleService.saveRole(updatedRole);
            return "redirect:/roles";
        } else {
            return "error/404";
        }
    }

    // Handle deletion of a role
    @PostMapping("/delete/{id}")
    public String deleteRole(@PathVariable Integer id) {
        if (roleService.getRoleById(id).isPresent()) {
            roleService.deleteRole(id);
            return "redirect:/roles";
        } else {
            return "error/404";
        }
    }
}
