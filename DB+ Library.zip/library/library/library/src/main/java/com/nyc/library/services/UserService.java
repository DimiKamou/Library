package com.nyc.library.services;

import com.nyc.library.entities.User;
import com.nyc.library.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // Fetch all users
    public List<User> getAllLibraryUsers() {
        return userRepository.findAll();
    }

    // Fetch users by role name
    public List<User> getUsersByRole(String roleName) {
        return userRepository.findByRole_RoleName(roleName); // Correct method to fetch users by role
    }


    // Fetch user by ID
    public Optional<User> getLibraryUserById(Integer id) {
        return userRepository.findById(id);
    }

    // Fetch user by username
    public Optional<User> getLibraryUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    // Save or update a user
    public User saveLibraryUser(User user) {
        return userRepository.save(user);
    }

    // Delete user by ID
    public void deleteLibraryUser(Integer id) {
        userRepository.deleteById(id);
    }
}
