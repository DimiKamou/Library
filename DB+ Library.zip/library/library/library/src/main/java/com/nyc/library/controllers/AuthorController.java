package com.nyc.library.controllers;

import com.nyc.library.entities.Author;
import com.nyc.library.services.AuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/authors")
public class AuthorController {

    private final AuthorService authorService;

    @Autowired
    public AuthorController(AuthorService authorService) {
        this.authorService = authorService;
    }

    /**
     * Display all authors.
     */
    @GetMapping
    public String getAllAuthors(Model model) {
        List<Author> allAuthors = authorService.getAllAuthors();
        model.addAttribute("authors", allAuthors);
        return "authors"; // Matches the authors.html template
    }

    /**
     * Show the form for adding a new author.
     */
    @GetMapping("/add")
    public String showAddAuthorForm(Model model) {
        model.addAttribute("author", new Author());
        return "author-form"; // Matches the author-form.html template
    }

    /**
     * Handle the creation of a new author.
     */
    @PostMapping("/save")
    public String saveAuthor(@ModelAttribute Author author) {
        authorService.saveAuthor(author);
        return "redirect:/authors"; // Redirect to the list of authors
    }

    /**
     * Display authors for editing.
     */
    @GetMapping("/edit")
    public String listAuthorsForEditing(Model model) {
        List<Author> authors = authorService.getAllAuthors();
        model.addAttribute("authors", authors);
        return "authors"; // Reuse the authors.html view
    }

    /**
     * Show the form for editing a specific author.
     */
    @GetMapping("/edit/{id}")
    public String showEditAuthorForm(@PathVariable Integer id, Model model) {
        Optional<Author> author = authorService.getAuthorById(id);
        if (author.isPresent()) {
            model.addAttribute("author", author.get());
            return "author-form"; // Reuse the same form for editing
        } else {
            return "error/404"; // Handle non-existent author
        }
    }

    /**
     * Handle updates to an existing author.
     */
    @PostMapping("/update/{id}")
    public String updateAuthor(@PathVariable Integer id, @ModelAttribute Author updatedAuthor) {
        Optional<Author> existingAuthor = authorService.getAuthorById(id);
        if (existingAuthor.isPresent()) {
            updatedAuthor.setId(existingAuthor.get().getId());
            authorService.saveAuthor(updatedAuthor);
            return "redirect:/authors"; // Redirect to the list of authors
        } else {
            return "error/404"; // Handle non-existent author
        }
    }

    /**
     * Handle the deletion of an author by ID.
     */
    @PostMapping("/delete/{id}")
    public String deleteAuthor(@PathVariable Integer id) {
        authorService.deleteAuthor(id);
        return "redirect:/authors"; // Redirect to the list of authors
    }

    /**
     * Display details of a specific author.
     */
    @GetMapping("/{id}")
    public String getAuthorDetails(@PathVariable Integer id, Model model) {
        Optional<Author> author = authorService.getAuthorById(id);
        if (author.isPresent()) {
            model.addAttribute("author", author.get());
            return "view-author"; // Matches the view-author.html template
        } else {
            return "error/404"; // Handle non-existent author
        }
    }
}
